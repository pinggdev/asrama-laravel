

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h4 class="card-title">Jadwal</h4>
    </div>
    <div class="card-content">
        <div class="card-body">           
            <div class="row">
                <div class="col-8 align-self-center">
                    <a href="<?php echo e(route('jadwal.create')); ?>" class="btn btn-primary btn-sm align-self-center">Tambah Jadwal</a>
                </div>
            </div>
            <!-- Table with outer spacing -->
            <div class="table-responsive">         
                <table class="table table-lg">
                    <thead>
                        <tr>
                            <th>NO</th>
                            <th>NAMA KEGIATAN</th>
                            <th>TANGGAL KEGIATAN</th>
                            <th>PENANGGUNG JAWAB</th>
                            <th>ACTION</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $x = 1;
                        ?>
                        <?php $__currentLoopData = $jadwals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jadwal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(Auth::user()->role === "siswa" && Auth::user()->id == $jadwal->user->id): ?>
                            
                            <tr>
                                <td scope="row" style="vertical-align: middle;"><?php echo e($x); ?></td>
                                <td class="text-bold-500"><?php echo e($jadwal->nama_kegiatan); ?></td>
                                <td class="text-bold-500"><?php echo e($jadwal->tanggal_kegiatan); ?></td>
                                <td class="text-bold-500"><?php echo e($jadwal->user->name); ?></td>
                                <td class="text-bold-500">
                                    <form action="<?php echo e(route('jadwal.destroy', $jadwal->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <a href="<?php echo e(route('jadwal.edit', $jadwal->id)); ?>" class="btn btn-success btn-sm">Edit</a>
                                        <?php if(Auth::user()->role === "admin"): ?>     
                                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                        <?php endif; ?>
                                    </form>
                                </td>
                                <?php
                                    $x++;
                                ?>
                            </tr>
                            <?php elseif(Auth::user()->role === "admin"): ?>
                                <tr>
                                    <td scope="row" style="vertical-align: middle;"><?php echo e($x); ?></td>
                                    <td class="text-bold-500"><?php echo e($jadwal->nama_kegiatan); ?></td>
                                    <td class="text-bold-500"><?php echo e($jadwal->tanggal_kegiatan); ?></td>
                                    <td class="text-bold-500"><?php echo e($jadwal->user->name); ?></td>
                                    <td class="text-bold-500">
                                        <form action="<?php echo e(route('jadwal.destroy', $jadwal->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <a href="<?php echo e(route('jadwal.edit', $jadwal->id)); ?>" class="btn btn-success btn-sm">Edit</a>
                                            <?php if(Auth::user()->role === "admin"): ?>     
                                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                            <?php endif; ?>
                                        </form>
                                    </td>
                                    <?php
                                        $x++;
                                    ?>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\asrama\resources\views/admin/jadwal/index.blade.php ENDPATH**/ ?>