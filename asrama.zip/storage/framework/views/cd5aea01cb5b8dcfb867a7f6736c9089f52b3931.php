

<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <h4 class="card-title">Absen</h4>
    </div>
    <div class="card-content">
        <div class="card-body">
            
            <?php if(Auth::user()->role === "admin"): ?>
                <div class="row">
                    <div class="col-8 align-self-center">
                        <a href="<?php echo e(route('absen.create')); ?>" class="btn btn-primary btn-sm align-self-center">Tambah Absen</a>
                    </div>
                </div>
            <?php endif; ?>
            <!-- Table with outer spacing -->
            <div class="table-responsive">         
                <table class="table table-lg">
                    <thead>
                        <tr>
                            <th>NO</th>
                            <th>NAMA PESERTA</th>
                            <th>NAMA KEGIATAN</th>
                            <th>TANGGAL KEGIATAN</th>
                            <th>STATUS</th>
                            <th>ACTION</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $x = 1;
                        ?>
                        <?php $__currentLoopData = $absens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $absen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Auth::user()->role === "siswa" && Auth::user()->id == $absen->user->id): ?>
                            <tr>
                                <td scope="row" style="vertical-align: middle;"><?php echo e($x); ?></td>
                                <td class="text-bold-500"><?php echo e($absen->user->name); ?></td>
                                <td class="text-bold-500"><?php echo e($absen->jadwal->nama_kegiatan); ?></td>
                                <td class="text-bold-500"><?php echo e($absen->jadwal->tanggal_kegiatan); ?></td>
                                <td class="text-bold-500"><?php echo e($absen->status); ?></td>
                                <td class="text-bold-500">
                                    <form action="<?php echo e(route('absen.destroy', $absen->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <a href="<?php echo e(route('absen.edit', $absen->id)); ?>" class="btn btn-success btn-sm">Edit</a>
                                        <?php if(Auth::user()->role === "admin"): ?>     
                                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                        <?php endif; ?>
                                    </form>
                                </td>
                                <?php
                                    $x++;
                                ?>
                            </tr>
                            <?php elseif(Auth::user()->role === "admin"): ?>
                            <tr>
                                <td scope="row" style="vertical-align: middle;"><?php echo e($x); ?></td>
                                <td class="text-bold-500"><?php echo e($absen->user->name); ?></td>
                                <td class="text-bold-500"><?php echo e($absen->jadwal->nama_kegiatan); ?></td>
                                <td class="text-bold-500"><?php echo e($absen->jadwal->tanggal_kegiatan); ?></td>
                                <td class="text-bold-500"><?php echo e($absen->status); ?></td>
                                <td class="text-bold-500">
                                    <form action="<?php echo e(route('absen.destroy', $absen->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <a href="<?php echo e(route('absen.edit', $absen->id)); ?>" class="btn btn-success btn-sm">Edit</a>
                                        <?php if(Auth::user()->role === "admin"): ?>     
                                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                        <?php endif; ?>
                                    </form>
                                </td>
                                <?php
                                    $x++;
                                ?>
                            </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\asrama\resources\views/admin/absen/index.blade.php ENDPATH**/ ?>