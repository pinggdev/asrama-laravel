

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h4 class="card-title">Siswa</h4>
    </div>
    <div class="card-content">
        <div class="card-body">
            <div class="row">
                <div class="col-8 align-self-center">
                    <a href="<?php echo e(route('siswa.create')); ?>" class="btn btn-primary btn-sm align-self-center">Tambah Siswa</a>
                </div>
            </div>
            <!-- Table with outer spacing -->
            <div class="table-responsive">         
                <table class="table table-lg">
                    <thead>
                        <tr>
                            <th>NO</th>
                            <th>NAMA</th>
                            <th>EMAIL</th>
                            <th>ASRAMA</th>
                            <th>ACTION</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $x = 1;
                        ?>
                        <?php $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td scope="row" style="vertical-align: middle;"><?php echo e($x); ?></td>
                                <td class="text-bold-500"><?php echo e($siswa->user->name); ?></td>
                                <td class="text-bold-500"><?php echo e($siswa->user->email); ?></td>
                                <td class="text-bold-500"><?php echo e($siswa->asrama->name); ?></td>
                                <td class="text-bold-500">
                                    <form action="<?php echo e(route('siswa.destroy', $siswa->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <a href="<?php echo e(route('siswa.edit', $siswa->id)); ?>" class="btn btn-success btn-sm">Edit</a>
                                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                    </form>
                                </td>
                                <?php
                                    $x++;
                                ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\asrama\resources\views/admin/siswa/index.blade.php ENDPATH**/ ?>