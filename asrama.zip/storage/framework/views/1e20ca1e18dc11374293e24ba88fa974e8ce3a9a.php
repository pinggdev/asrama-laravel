

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h4 class="card-title">Rekap Absen Bulanan</h4>
    </div>
    <div class="card-content">
        <div class="card-body">
            <div class="row">
                <div class="col-8">
                    <form method="get" action="<?php echo e(route('absen.rekapbulanan')); ?>">
                        <div class="form-group row">
                            <label for="bulan" class="col-md-3 col-form-label text-md-right">Bulan</label>

                            <div class="col-md-6">
                                <select id="bulan" name="bulan" class="form-control">
                                    <option value="">-- Semua --</option>
                                    <option value="01"<?php echo e(old('bulan') == '01' ? ' selected' : ''); ?>>Januari</option>
                                    <option value="02"<?php echo e(old('bulan') == '02' ? ' selected' : ''); ?>>Februari</option>
                                    <option value="03"<?php echo e(old('bulan') == '03' ? ' selected' : ''); ?>>Maret</option>
                                    <option value="04"<?php echo e(old('bulan') == '04' ? ' selected' : ''); ?>>April</option>
                                    <option value="05"<?php echo e(old('bulan') == '05' ? ' selected' : ''); ?>>Mei</option>
                                    <option value="06"<?php echo e(old('bulan') == '06' ? ' selected' : ''); ?>>Juni</option>
                                    <option value="07"<?php echo e(old('bulan') == '07' ? ' selected' : ''); ?>>Juli</option>
                                    <option value="08"<?php echo e(old('bulan') == '08' ? ' selected' : ''); ?>>Agustus</option>
                                    <option value="09"<?php echo e(old('bulan') == '09' ? ' selected' : ''); ?>>September</option>
                                    <option value="10"<?php echo e(old('bulan') == '10' ? ' selected' : ''); ?>>Oktober</option>
                                    <option value="11"<?php echo e(old('bulan') == '11' ? ' selected' : ''); ?>>November</option>
                                    <option value="12"<?php echo e(old('bulan') == '12' ? ' selected' : ''); ?>>Desember</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <button type="submit" class="btn btn-primary">Filter</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <!-- Table with outer spacing -->
            <div class="table-responsive">         
                <table class="table table-lg">
                    <thead>
                        <tr>
                            <th>NO</th>
                            <th>NAMA SISWA</th>
                            <th>JUMLAH HADIR</th>
                            <th>JUMLAH TIDAK HADIR</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $x = 1;
                        ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td scope="row" style="vertical-align: middle;"><?php echo e($x); ?></td>
                                <td class="text-bold-500"><?php echo e($dt['user']); ?></td>
                                <td class="text-bold-500"><?php echo e($dt['hadir']); ?></td>
                                <td class="text-bold-500"><?php echo e($dt['tidak_hadir']); ?></td>
                                </tr>
                            <?php
                            $x++;
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
                                    
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\asrama\resources\views/admin/rekap/index.blade.php ENDPATH**/ ?>