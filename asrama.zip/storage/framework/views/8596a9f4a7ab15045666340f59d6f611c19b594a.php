<?php echo $__env->make('layouts.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <div id="app">
        <?php echo $__env->make('layouts.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="main">
            <header class="mb-3">
                <a href="#" class="burger-btn d-block d-xl-none">
                    <i class="bi bi-justify fs-3"></i>
                </a>
            </header>

            <div class="page-heading">
                <h3>Dashboard</h3>
                <h4>Selamat Datang <?php echo e(Auth::user()->name); ?></h4>
                <?php if(Auth::user()->role === "admin"): ?>
                    <p></p>
                <?php elseif(!Auth::user()->siswa && Auth::user()->role === "siswa"): ?>
                    <p>Anda belum terdaftar dalam asrama, hubungi admin!</p>
                <?php endif; ?>
            </div>
            <div class="page-content">
                <?php echo $__env->yieldContent('content'); ?>
            </div>


        </div>
    </div>
    <script src="<?php echo e(('assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js')); ?>""></script>
    <script src="<?php echo e(('assets/js/bootstrap.bundle.min.js')); ?>""></script>

    <script src="<?php echo e(('assets/vendors/apexcharts/apexcharts.js')); ?>""></script>
    <script src="<?php echo e(('assets/js/pages/dashboard.js')); ?>""></script>

    <script src="<?php echo e(('assets/js/main.js')); ?>""></script>
</body>

</html><?php /**PATH D:\xampp\htdocs\asrama\resources\views/layouts/master.blade.php ENDPATH**/ ?>